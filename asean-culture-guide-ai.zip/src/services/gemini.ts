import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface CulturalInfo {
  food: { name: string; description: string; etiquette?: string; imageUrl: string }[];
  clothing: { name: string; description: string; situations?: string; imageUrl: string }[];
  language: { phrases: { phrase: string; meaning: string }[]; etiquette: string; dialects?: string[] };
  etiquette: { dos: string[]; donts: string[]; greetings?: string; giftGiving?: string; socialNorms?: string };
  dance: { name: string; description: string; imageUrl: string }[];
  culture: { traditions: string[]; festivals: string[]; laws?: string[] };
  ethnicity?: string[];
  generalInfo?: string;
}

export const getCulturalInsights = async (country: string): Promise<CulturalInfo> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Provide detailed cultural insights for ${country} in ASEAN. Focus on food, clothing, language, etiquette (dos and donts), dance, and general culture. Format as JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          food: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                imageUrl: { type: Type.STRING, description: "A descriptive search query for an image of this food" }
              },
              required: ["name", "description", "imageUrl"]
            }
          },
          clothing: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                imageUrl: { type: Type.STRING, description: "A descriptive search query for an image of this clothing" }
              },
              required: ["name", "description", "imageUrl"]
            }
          },
          language: {
            type: Type.OBJECT,
            properties: {
              phrases: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    phrase: { type: Type.STRING },
                    meaning: { type: Type.STRING }
                  }
                }
              },
              etiquette: { type: Type.STRING }
            }
          },
          etiquette: {
            type: Type.OBJECT,
            properties: {
              dos: { type: Type.ARRAY, items: { type: Type.STRING } },
              donts: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          },
          dance: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                imageUrl: { type: Type.STRING, description: "A descriptive search query for an image of this dance" }
              }
            }
          },
          culture: {
            type: Type.OBJECT,
            properties: {
              traditions: { type: Type.ARRAY, items: { type: Type.STRING } },
              festivals: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          }
        },
        required: ["food", "clothing", "language", "etiquette", "dance", "culture"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const scanCultureImage = async (base64Image: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        { inlineData: { data: base64Image.split(",")[1], mimeType: "image/jpeg" } },
        { text: `Identify what cultural element of ${country} is in this image. Explain its significance, history, and any etiquette related to it. If it's not related to ${country}, please clarify.` }
      ]
    }
  });
  return response.text;
};

export const translateSignLanguage = async (base64Image: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        { inlineData: { data: base64Image.split(",")[1], mimeType: "image/jpeg" } },
        { text: `Translate the sign language gesture in this image. The context is ${country}. Identify the specific sign language (e.g., Filipino Sign Language, Thai Sign Language) and provide the meaning of the gesture.` }
      ]
    }
  });
  return response.text;
};

export const getSustainableTourismPlan = async (interests: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Act as an Ethical & Sustainable Tourism Planner for ${country}. Based on these interests: "${interests}", suggest an "Impact Route". Recommend local social enterprises, eco-friendly stays, and community-led workshops (e.g., traditional weaving). Explain how this supports SDG 11 (Sustainable Cities) and SDG 13 (Climate Action).`,
  });
  return response.text;
};

export const getAgriculturalAdvice = async (query: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Act as a Traditional Agricultural Wisdom Engine for ${country}. Combine historical local farming knowledge (like Subak in Bali or Rice Terraces in Philippines) with climate resilience advice. Address this query: "${query}". Provide advice on crop rotation and disaster resilience while honoring ancestral methods. (SDG 13).`,
  });
  return response.text;
};

export const getArtisanSupport = async (craftDescription: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Act as an AI Artisan Marketplace Assistant for a rural artisan in ${country}. The craft is: "${craftDescription}". 
    1. Generate a high-quality, poetic product description in English and the local language.
    2. Suggest potential global markets or buyers.
    3. Provide a brief overview of cross-border logistics considerations.
    (SDG 9 & 10).`,
  });
  return response.text;
};

export const preserveDialect = async (transcription: string, country: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Act as an Indigenous Language & Dialect Preservation Expert for ${country}. Analyze this transcription of a rare dialect/tongue: "${transcription}". 
    1. Identify the dialect if possible.
    2. Explain its historical significance and current status (endangered level).
    3. Provide a few key grammatical rules or unique vocabulary found in this snippet.
    (SDG 4 & 10).`,
  });
  return response.text;
};
