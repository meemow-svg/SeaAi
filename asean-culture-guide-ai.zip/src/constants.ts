export interface CountryTheme {
  id: string;
  name: string;
  code: string;
  capital: string;
  primaryColor: string; // Tailwind class for light bg
  secondaryColor: string; // Tailwind class for text
  accentColor: string; // Tailwind class for border
  hexColor: string; // Main theme color hex
  greeting: string;
  bgImage: string;
  flag: string;
}

export const ASEAN_COUNTRIES: CountryTheme[] = [
  {
    id: "malaysia",
    name: "Malaysia",
    code: "MY",
    capital: "Kuala Lumpur",
    primaryColor: "bg-[#D1E1F5]",
    secondaryColor: "text-[#3F51B5]",
    accentColor: "border-[#3F51B5]",
    hexColor: "#3F51B5",
    greeting: "Selamat datang!",
    bgImage: "https://picsum.photos/seed/malaysia/1920/1080?blur=5",
    flag: "🇲🇾"
  },
  {
    id: "indonesia",
    name: "Indonesia",
    code: "ID",
    capital: "Jakarta",
    primaryColor: "bg-[#F5E1E1]",
    secondaryColor: "text-[#B71C1C]",
    accentColor: "border-[#B71C1C]",
    hexColor: "#B71C1C",
    greeting: "Selamat datang!",
    bgImage: "https://picsum.photos/seed/indonesia/1920/1080?blur=5",
    flag: "🇮🇩"
  },
  {
    id: "thailand",
    name: "Thailand",
    code: "TH",
    capital: "Bangkok",
    primaryColor: "bg-[#E1E1F5]",
    secondaryColor: "text-[#673AB7]",
    accentColor: "border-[#673AB7]",
    hexColor: "#673AB7",
    greeting: "Sawatdee krab/ka!",
    bgImage: "https://picsum.photos/seed/thailand/1920/1080?blur=5",
    flag: "🇹🇭"
  },
  {
    id: "vietnam",
    name: "Vietnam",
    code: "VN",
    capital: "Hanoi",
    primaryColor: "bg-[#F5E1E1]",
    secondaryColor: "text-[#B71C1C]",
    accentColor: "border-[#B71C1C]",
    hexColor: "#B71C1C",
    greeting: "Xin chào!",
    bgImage: "https://picsum.photos/seed/vietnam/1920/1080?blur=5",
    flag: "🇻🇳"
  },
  {
    id: "philippines",
    name: "Philippines",
    code: "PH",
    capital: "Manila",
    primaryColor: "bg-[#D1E1F5]",
    secondaryColor: "text-[#3F51B5]",
    accentColor: "border-[#3F51B5]",
    hexColor: "#3F51B5",
    greeting: "Mabuhay!",
    bgImage: "https://picsum.photos/seed/philippines/1920/1080?blur=5",
    flag: "🇵🇭"
  },
  {
    id: "singapore",
    name: "Singapore",
    code: "SG",
    capital: "Singapore",
    primaryColor: "bg-[#F5E1E1]",
    secondaryColor: "text-[#B71C1C]",
    accentColor: "border-[#B71C1C]",
    hexColor: "#B71C1C",
    greeting: "Welcome!",
    bgImage: "https://picsum.photos/seed/singapore/1920/1080?blur=5",
    flag: "🇸🇬"
  },
  {
    id: "myanmar",
    name: "Myanmar",
    code: "MM",
    capital: "Naypyidaw",
    primaryColor: "bg-[#F5F5E1]",
    secondaryColor: "text-[#827717]",
    accentColor: "border-[#827717]",
    hexColor: "#827717",
    greeting: "Mingalaba!",
    bgImage: "https://picsum.photos/seed/myanmar/1920/1080?blur=5",
    flag: "🇲🇲"
  },
  {
    id: "cambodia",
    name: "Cambodia",
    code: "KH",
    capital: "Phnom Penh",
    primaryColor: "bg-[#D1E1F5]",
    secondaryColor: "text-[#3F51B5]",
    accentColor: "border-[#3F51B5]",
    hexColor: "#3F51B5",
    greeting: "Choum reap sour!",
    bgImage: "https://picsum.photos/seed/cambodia/1920/1080?blur=5",
    flag: "🇰🇭"
  },
  {
    id: "laos",
    name: "Laos",
    code: "LA",
    capital: "Vientiane",
    primaryColor: "bg-[#F5E1E1]",
    secondaryColor: "text-[#B71C1C]",
    accentColor: "border-[#B71C1C]",
    hexColor: "#B71C1C",
    greeting: "Sabaidee!",
    bgImage: "https://picsum.photos/seed/laos/1920/1080?blur=5",
    flag: "🇱🇦"
  },
  {
    id: "brunei",
    name: "Brunei",
    code: "BN",
    capital: "Bandar Seri Begawan",
    primaryColor: "bg-[#F5F5E1]",
    secondaryColor: "text-[#827717]",
    accentColor: "border-[#827717]",
    hexColor: "#827717",
    greeting: "Selamat pagi!",
    bgImage: "https://picsum.photos/seed/brunei/1920/1080?blur=5",
    flag: "🇧🇳"
  },
  {
    id: "timor-leste",
    name: "Timor Leste",
    code: "TL",
    capital: "Dili",
    primaryColor: "bg-[#F5E1E1]",
    secondaryColor: "text-[#B71C1C]",
    accentColor: "border-[#B71C1C]",
    hexColor: "#B71C1C",
    greeting: "Bondia!",
    bgImage: "https://picsum.photos/seed/timorleste/1920/1080?blur=5",
    flag: "🇹🇱"
  }
];
