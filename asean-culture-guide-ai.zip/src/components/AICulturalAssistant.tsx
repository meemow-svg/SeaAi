import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import { 
  MessageSquare, 
  Sparkles, 
  Globe, 
  ShieldAlert, 
  Users, 
  Send, 
  X, 
  ChevronRight,
  RefreshCw,
  BookOpen
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from '../services/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

type Mode = 'chat' | 'translate' | 'mediate' | 'simulate' | 'icc' | 'tourism' | 'agriculture' | 'artisan' | 'dialect';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const AICulturalAssistant: React.FC<{ countryName?: string; onClose?: () => void }> = ({ countryName, onClose }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  // Auto-open if onClose is provided (meaning it's being used as a modal/overlay)
  useEffect(() => {
    if (onClose) {
      setIsOpen(true);
    }
  }, [onClose]);

  const handleClose = () => {
    setIsOpen(false);
    if (onClose) {
      // Small delay to allow exit animation
      setTimeout(() => {
        onClose();
      }, 200);
    }
  };
  const [mode, setMode] = useState<Mode>('chat');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      let systemInstruction = "";
      
      switch (mode) {
        case 'translate':
          systemInstruction = `You are a Cultural Translation Expert for ASEAN countries. 
          When translating, don't just give the words. 
          1. Provide the translation.
          2. Explain the cultural context (why these words are used).
          3. Interpret social cues (tone, politeness level like 'honorifics').
          4. Suggest the best way to deliver the message (body language, eye contact).
          Focus on ${countryName || 'ASEAN cultures'}.`;
          break;
        case 'mediate':
          systemInstruction = `You are an Intercultural Conflict Mediator. 
          Help the user understand a misunderstanding or conflict involving ${countryName || 'ASEAN'} cultures.
          Analyze the situation from both cultural perspectives.
          Suggest ways to resolve the conflict with respect and "saving face".`;
          break;
        case 'simulate':
          systemInstruction = `You are a Cultural Simulation Engine. 
          Recreate a cultural or historical situation in ${countryName || 'an ASEAN country'}.
          Describe the scene vividly and ask the user how they would react.
          Then explain the cultural implications of their choice.`;
          break;
        case 'icc':
          systemInstruction = `You are an Intercultural Communicative Competence (ICC) Coach.
          Help the user build their ability to communicate effectively across cultures.
          Provide mini-lessons, quizzes, or scenarios to test their cultural intelligence (CQ).`;
          break;
        case 'tourism':
          systemInstruction = `You are an Ethical & Sustainable Tourism Planner for ${countryName || 'ASEAN countries'}. 
          Suggest "Impact Routes" that support local social enterprises, eco-friendly stays, and community-led workshops. 
          Focus on SDG 11 and 13.`;
          break;
        case 'agriculture':
          systemInstruction = `You are a Traditional Agricultural Wisdom Engine for ${countryName || 'ASEAN countries'}. 
          Combine historical local farming knowledge with modern climate resilience advice. 
          Focus on SDG 13 and preserving ancestral methods.`;
          break;
        case 'artisan':
          systemInstruction = `You are an AI Artisan Marketplace Assistant for rural creators in ${countryName || 'ASEAN countries'}. 
          Help digitize crafts by generating descriptions, suggesting global markets, and explaining logistics. 
          Focus on SDG 9 and 10.`;
          break;
        case 'dialect':
          systemInstruction = `You are an Indigenous Language & Dialect Preservation Expert for ${countryName || 'ASEAN countries'}. 
          Analyze rare dialects, explain their significance, and provide linguistic insights to help preserve oral history. 
          Focus on SDG 4 and 10.`;
          break;
        default:
          systemInstruction = `You are a wise and helpful Cultural Guide for ${countryName || 'ASEAN countries'}. 
          You help travelers understand deep cultural nuances, traditions, and social etiquette.`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [...messages, userMessage].map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction,
        },
      });

      const modelText = response.text || "I'm sorry, I couldn't process that cultural nuance.";
      setMessages(prev => [...prev, { role: 'model', text: modelText }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "The cultural spirits are quiet right now. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const modes = [
    { id: 'chat', label: 'Guide', icon: MessageSquare, color: 'text-blue-500' },
    { id: 'translate', label: 'Translator+', icon: Globe, color: 'text-emerald-500' },
    { id: 'tourism', label: 'Eco-Tourism', icon: BookOpen, color: 'text-green-500' },
    { id: 'agriculture', label: 'Agri-Wisdom', icon: Sparkles, color: 'text-orange-500' },
    { id: 'artisan', label: 'Artisan Hub', icon: Users, color: 'text-pink-500' },
    { id: 'dialect', label: 'Dialect Save', icon: BookOpen, color: 'text-cyan-500' },
    { id: 'mediate', label: 'Mediator', icon: ShieldAlert, color: 'text-amber-500' },
    { id: 'simulate', label: 'Simulator', icon: Sparkles, color: 'text-purple-500' },
    { id: 'icc', label: 'ICC Coach', icon: Users, color: 'text-rose-500' },
  ];

  return (
    <>
      {/* Floating Trigger - Only show if not managed by parent (no onClose) */}
      {!onClose && (
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsOpen(true)}
          className="fixed bottom-8 right-8 z-50 w-16 h-16 bg-[#F27D26] rounded-full shadow-2xl flex items-center justify-center text-white border-2 border-white/20"
        >
          <Sparkles className="w-8 h-8" />
        </motion.button>
      )}

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop for modal mode */}
            {onClose && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={handleClose}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
              />
            )}
            
            <motion.div
              initial={{ opacity: 0, y: 100, scale: 0.9, x: onClose ? '-50%' : 0 }}
              animate={{ opacity: 1, y: onClose ? '-50%' : 0, scale: 1, x: onClose ? '-50%' : 0 }}
              exit={{ opacity: 0, y: 100, scale: 0.9, x: onClose ? '-50%' : 0 }}
              style={onClose ? {
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)'
              } : {}}
              className={cn(
                "fixed z-[70] w-[95vw] md:w-[500px] max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E2E8F0]",
                onClose ? "" : "bottom-28 right-8 h-[600px]"
              )}
            >
              {/* Header */}
              <div className="p-5 md:p-6 bg-[#1A110E] text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#F27D26] rounded-full flex items-center justify-center shrink-0">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg md:text-xl">Cultural AI Assistant</h3>
                    <p className="text-[10px] md:text-xs text-white/60">Powered by Gemini 3</p>
                  </div>
                </div>
                <button 
                  onClick={handleClose} 
                  className="p-2 hover:bg-white/20 rounded-full transition-colors bg-white/10"
                  aria-label="Close Assistant"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

            {/* Mode Selector */}
            <div className="flex overflow-x-auto p-4 gap-2 border-bottom border-[#E2E8F0] bg-[#F8FAFC]">
              {modes.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setMode(m.id as Mode);
                    setMessages([]);
                  }}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap",
                    mode === m.id 
                      ? "bg-white shadow-sm border border-[#E2E8F0] text-[#1E293B]" 
                      : "text-[#64748B] hover:bg-white/50"
                  )}
                >
                  <m.icon className={cn("w-4 h-4", m.color)} />
                  {m.label}
                </button>
              ))}
            </div>

            {/* Chat Area */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#F1F5F9]/30"
            >
              {messages.length === 0 && (
                <div className="text-center py-12 space-y-4">
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-[#E2E8F0] flex items-center justify-center mx-auto">
                    {React.createElement(modes.find(m => m.id === mode)?.icon || MessageSquare, { className: cn("w-8 h-8", modes.find(m => m.id === mode)?.color) })}
                  </div>
                  <div className="max-w-[280px] mx-auto">
                    <h4 className="font-serif text-lg text-[#1E293B]">
                      {mode === 'chat' && `Ask me anything about ${countryName || 'ASEAN'} culture.`}
                      {mode === 'translate' && "Translate with deep cultural context."}
                      {mode === 'mediate' && "Describe a cultural misunderstanding."}
                      {mode === 'simulate' && "Start a virtual cultural experience."}
                      {mode === 'icc' && "Test your Intercultural Competence."}
                      {mode === 'tourism' && "Plan an ethical and sustainable impact route."}
                      {mode === 'agriculture' && "Get agricultural advice rooted in traditional wisdom."}
                      {mode === 'artisan' && "Digitize and market rural artisan crafts."}
                      {mode === 'dialect' && "Preserve rare dialects and indigenous languages."}
                    </h4>
                    <p className="text-sm text-[#64748B] mt-2">
                      I'm here to help you bridge cultural gaps with respect and intelligence.
                    </p>
                  </div>
                </div>
              )}

              {messages.map((m, i) => (
                <motion.div
                  initial={{ opacity: 0, x: m.role === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i}
                  className={cn(
                    "flex flex-col max-w-[85%]",
                    m.role === 'user' ? "ml-auto items-end" : "mr-auto items-start"
                  )}
                >
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed",
                    m.role === 'user' 
                      ? "bg-[#1E293B] text-white rounded-tr-none" 
                      : "bg-white border border-[#E2E8F0] text-[#1E293B] shadow-sm rounded-tl-none"
                  )}>
                    <div className="prose prose-sm max-w-none">
                      <ReactMarkdown>
                        {m.text}
                      </ReactMarkdown>
                    </div>
                  </div>
                  <span className="text-[10px] text-[#94A3B8] mt-1 uppercase tracking-widest">
                    {m.role === 'user' ? 'You' : 'Cultural AI'}
                  </span>
                </motion.div>
              ))}
              
              {isLoading && (
                <div className="flex items-center gap-2 text-[#64748B] text-xs animate-pulse">
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  Interpreting cultural nuances...
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-[#E2E8F0]">
              <div className="relative">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={
                    mode === 'translate' ? "Enter text to translate..." :
                    mode === 'simulate' ? "Type 'Start' to begin simulation..." :
                    "Type your message..."
                  }
                  className="w-full p-4 pr-12 bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F27D26]/50 resize-none h-20"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="absolute bottom-3 right-3 p-2 bg-[#F27D26] text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <p className="text-[10px] text-[#94A3B8] mt-2 text-center">
                AI can make mistakes. Always verify critical cultural information.
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  </>
);
};
