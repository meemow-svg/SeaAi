import { CulturalInfo } from '../services/gemini';

export const CULTURAL_DATA: Record<string, CulturalInfo> = {
  "Malaysia": {
    food: [
      { name: "Nasi Lemak", description: "Fragrant rice cooked in coconut milk and pandan leaf, served with sambal, anchovies, peanuts, and boiled egg.", etiquette: "Often eaten for breakfast, traditionally wrapped in banana leaf.", imageUrl: "nasi-lemak" },
      { name: "Laksa", description: "Spicy noodle soup with a variety of regional variations, often featuring a coconut milk or sour tamarind base.", etiquette: "Slurping is generally acceptable but not as common as in East Asia.", imageUrl: "laksa" },
      { name: "Roti Canai", description: "A flatbread of Indian origin, usually served with dhal or curry.", etiquette: "Best eaten with hands; use your right hand to tear the bread.", imageUrl: "roti-canai" },
      { name: "Satay", description: "Seasoned, skewered and grilled meat, served with a savory peanut sauce.", etiquette: "Dip the skewer into the peanut sauce provided in a communal bowl or individual plate.", imageUrl: "satay" }
    ],
    clothing: [
      { name: "Baju Melayu", description: "Traditional Malay outfit for men, consisting of a long-sleeved shirt, trousers, and a sampin (sarong).", situations: "Worn during formal occasions, weddings, and Friday prayers.", imageUrl: "baju-melayu" },
      { name: "Baju Kurung", description: "Traditional Malay dress for women, consisting of a long skirt and a loose-fitting blouse.", situations: "Standard formal and office wear for Malay women; also worn at festivals.", imageUrl: "baju-kurung" },
      { name: "Cheongsam", description: "Traditional Chinese dress worn by women.", situations: "Worn during Chinese New Year and weddings.", imageUrl: "cheongsam" },
      { name: "Saree", description: "Traditional Indian garment worn by women.", situations: "Worn during Deepavali and Indian weddings.", imageUrl: "saree" }
    ],
    language: {
      phrases: [
        { phrase: "Selamat Pagi", meaning: "Good Morning" },
        { phrase: "Terima Kasih", meaning: "Thank You" },
        { phrase: "Sama-sama", meaning: "You're Welcome" },
        { phrase: "Apa Khabar?", meaning: "How are you?" }
      ],
      etiquette: "Malay is the official language, but English is widely used. Chinese dialects and Tamil are also common.",
      dialects: ["Kelantanese", "Kedahan", "Sarawakian Malay", "Sabahan Malay"]
    },
    etiquette: {
      dos: [
        "Remove shoes when entering a home or place of worship.",
        "Dress modestly, especially when visiting religious sites.",
        "Use your right hand for social interactions.",
        "Accept food or drink offered by a host."
      ],
      donts: [
        "Don't touch someone's head, as it is considered sacred.",
        "Don't point with your index finger; use your thumb instead.",
        "Don't show public displays of affection.",
        "Don't make insensitive religious remarks."
      ],
      greetings: "A handshake is common, but some Malay women may prefer a nod and a smile to men. The 'Salam' (touching palms and bringing to heart) is traditional.",
      giftGiving: "Avoid giving alcohol or pork products to Muslims. Use both hands to give and receive gifts.",
      socialNorms: "Respect for elders is paramount. 'Saving face' is important in social interactions."
    },
    dance: [
      { name: "Zapin", description: "A popular dance in Johor, performed to the accompaniment of the gambus and drums.", imageUrl: "zapin" },
      { name: "Lion Dance", description: "Traditional Chinese dance performed during festivals.", imageUrl: "lion-dance" },
      { name: "Bharatanatyam", description: "Classical Indian dance.", imageUrl: "bharatanatyam" },
      { name: "Silat", description: "A traditional Malay martial art that is also performed as a dance.", imageUrl: "silat" }
    ],
    culture: {
      traditions: ["Open House during festivals", "Respect for elders", "Multicultural harmony"],
      festivals: ["Hari Raya Aidilfitri", "Chinese New Year", "Deepavali", "Thaipusam"],
      laws: ["Strict drug laws", "Sharia law applies to Muslims in certain matters"]
    },
    ethnicity: ["Malay (50%+)", "Chinese (22%)", "Indian (7%)", "Indigenous groups (Iban, Kadazan, Orang Asli)"],
    generalInfo: "Federal constitutional monarchy with a strong multicultural identity and a mix of modern and traditional lifestyles."
  },
  "Indonesia": {
    food: [
      { name: "Nasi Goreng", description: "Indonesian fried rice, often served with a fried egg, crackers, and pickles.", etiquette: "Can be eaten at any time of day, often with a spoon and fork.", imageUrl: "nasi-goreng" },
      { name: "Rendang", description: "Slow-cooked beef in coconut milk and spices until the liquid evaporates and the meat is tender.", etiquette: "A celebratory dish, often served at weddings and Idul Fitri.", imageUrl: "rendang" },
      { name: "Satay", description: "Seasoned, skewered and grilled meat, served with a savory peanut sauce.", etiquette: "Common street food; eat directly from the skewer.", imageUrl: "satay" },
      { name: "Gado-Gado", description: "A salad of boiled vegetables, hard-boiled eggs, fried tofu and tempeh, served with peanut sauce.", etiquette: "A healthy staple found throughout Java.", imageUrl: "gado-gado" }
    ],
    clothing: [
      { name: "Batik", description: "A traditional fabric-dyeing technique using wax-resist, often worn as shirts or sarongs.", situations: "Worn for both formal and casual occasions; Batik Friday is a common practice in offices.", imageUrl: "batik" },
      { name: "Kebaya", description: "A traditional blouse-dress combination worn by Indonesian women.", situations: "Worn at weddings, formal events, and national celebrations.", imageUrl: "kebaya" },
      { name: "Ulos", description: "Traditional textile of the Batak people of North Sumatra.", situations: "Used in traditional ceremonies like weddings and funerals.", imageUrl: "ulos" }
    ],
    language: {
      phrases: [
        { phrase: "Selamat Siang", meaning: "Good Afternoon" },
        { phrase: "Terima Kasih", meaning: "Thank You" },
        { phrase: "Apa Kabar?", meaning: "How are you?" }
      ],
      etiquette: "Bahasa Indonesia is the official language, but there are over 700 regional languages spoken.",
      dialects: ["Javanese", "Sundanese", "Balinese", "Minangkabau", "Buginese"]
    },
    etiquette: {
      dos: ["Smile and be polite", "Use your right hand", "Remove shoes indoors", "Respect elders"],
      donts: ["Don't touch heads", "Don't use your left hand for eating", "Don't point with feet", "Don't disrespect religion publicly"],
      greetings: "A handshake is standard, often followed by touching one's own chest. The 'Sembah' (palms together) is used in Java and Bali.",
      giftGiving: "Avoid giving sharp objects. Gifts are usually not opened in front of the giver.",
      socialNorms: "Gossip is common but public confrontation is avoided. 'Jam Karet' (rubber time) refers to a relaxed approach to punctuality."
    },
    dance: [
      { name: "Balinese Dance", description: "Intricate and expressive traditional dances from Bali.", imageUrl: "balinese-dance" },
      { name: "Saman Dance", description: "The 'Dance of a Thousand Hands' from Aceh.", imageUrl: "saman" },
      { name: "Reog", description: "A traditional dance from East Java involving large masks.", imageUrl: "reog" },
      { name: "Wayang Kulit", description: "Traditional shadow puppetry.", imageUrl: "wayang-kulit" }
    ],
    culture: {
      traditions: ["Gotong Royong (Mutual Aid)", "Strong family system", "Religious diversity"],
      festivals: ["Idul Fitri", "Nyepi", "Waisak"],
      laws: ["Strict drug laws", "Local regulations (Perda) can vary by region (e.g., Aceh)"]
    },
    ethnicity: ["Javanese (40%)", "Sundanese (15%)", "Malay", "Batak", "Madurese", "Over 300 ethnic groups"],
    generalInfo: "Largest country in Southeast Asia by population with very high cultural diversity across its 17,000+ islands."
  },
  "Thailand": {
    food: [
      { name: "Tom Yum", description: "Spicy and sour soup with lemongrass, kaffir lime leaves, and galangal.", etiquette: "Usually served in a communal bowl; use a spoon to serve yourself.", imageUrl: "tom-yum" },
      { name: "Pad Thai", description: "Stir-fried rice noodles with eggs, tofu, and tamarind pulp.", etiquette: "Often eaten with a fork and spoon; the fork is used to push food onto the spoon.", imageUrl: "pad-thai" },
      { name: "Green Curry", description: "Spicy coconut-based curry with green chilies and herbs.", etiquette: "Eaten with steamed rice.", imageUrl: "green-curry" },
      { name: "Som Tam", description: "Spicy green papaya salad.", etiquette: "A popular street food; can be very spicy.", imageUrl: "som-tam" }
    ],
    clothing: [
      { name: "Thai Silk", description: "Traditional Thai silk clothing, known for its quality and patterns.", situations: "Worn for formal events and traditional ceremonies.", imageUrl: "thai-silk" },
      { name: "Royal Ceremonial Attire", description: "Exquisite clothing worn for royal and formal occasions.", situations: "Strictly for royal or high-level state functions.", imageUrl: "royal-thai-attire" }
    ],
    language: {
      phrases: [
        { phrase: "Sawatdee Krab/Ka", meaning: "Hello" },
        { phrase: "Khob Khun Krab/Ka", meaning: "Thank You" }
      ],
      etiquette: "Thai is the official language. The 'Wai' greeting is essential.",
      dialects: ["Isan", "Northern Thai (Kam Mueang)", "Southern Thai"]
    },
    etiquette: {
      dos: ["Wai when greeting", "Dress modestly in temples", "Respect the King", "Temple-centered traditions"],
      donts: ["Don't touch heads", "Don't point with feet", "Don't disrespect Buddha images", "Don't disrespect the monarchy"],
      greetings: "The 'Wai' (palms together at chest/face level) is the standard greeting. The higher the hands, the more respect shown.",
      giftGiving: "Gifts are usually wrapped nicely. Avoid giving marigolds or carnations as they are associated with funerals.",
      socialNorms: "The concept of 'Greng Jai' (consideration for others' feelings) is central to Thai social harmony."
    },
    dance: [
      { name: "Khon", description: "A masked dance drama based on the Ramakien.", imageUrl: "khon" },
      { name: "Classical Thai Dance", description: "Elegant and stylized traditional dance.", imageUrl: "thai-dance" }
    ],
    culture: {
      traditions: ["Songkran Water Festival", "Loy Krathong", "Respect for monarchy", "Buddhist influence"],
      festivals: ["Songkran", "Loy Krathong", "Yi Peng"],
      laws: ["Lèse-majesté laws are very strict", "Strict drug laws"]
    },
    ethnicity: ["Thai (90%)", "Chinese", "Malay", "Hill tribe minorities (Karen, Hmong)"],
    generalInfo: "Known as the 'Land of Smiles', Thailand has a deeply rooted Buddhist culture and a strong sense of national identity."
  },
  "Vietnam": {
    food: [
      { name: "Pho", description: "A Vietnamese soup consisting of broth, rice noodles, herbs, and meat (usually beef or chicken).", etiquette: "Eaten with chopsticks and a spoon for the broth.", imageUrl: "pho" },
      { name: "Banh Mi", description: "A Vietnamese sandwich consisting of a baguette filled with various savory ingredients.", etiquette: "A popular street food, often eaten on the go.", imageUrl: "banh-mi" },
      { name: "Bun Cha", description: "Grilled pork and noodles, a specialty of Hanoi.", etiquette: "Dip the noodles and herbs into the bowl of broth and pork.", imageUrl: "bun-cha" }
    ],
    clothing: [
      { name: "Ao Dai", description: "A long, split tunic worn over silk trousers, the national garment of Vietnam.", situations: "Worn by women for formal occasions, weddings, and as school uniforms in some regions.", imageUrl: "ao-dai" },
      { name: "Non La", description: "Traditional conical hat made of palm leaves.", situations: "Worn for protection from sun and rain, often by farmers and street vendors.", imageUrl: "non-la" }
    ],
    language: {
      phrases: [
        { phrase: "Xin Chao", meaning: "Hello" },
        { phrase: "Cam On", meaning: "Thank You" }
      ],
      etiquette: "Vietnamese culture is influenced by Confucianism, emphasizing respect for family and elders.",
      dialects: ["Northern (Hanoi)", "Central (Hue)", "Southern (Saigon)"]
    },
    etiquette: {
      dos: ["Bow slightly to elders", "Use both hands when giving/receiving", "Remove shoes indoors"],
      donts: ["Don't touch heads", "Don't point with one finger", "Don't leave chopsticks sticking up in rice"],
      greetings: "A handshake is common, but a slight bow to elders is a sign of deep respect.",
      giftGiving: "Avoid giving handkerchiefs (associated with sadness) or anything black. Gifts are usually wrapped in red or yellow paper.",
      socialNorms: "Modesty and humility are highly valued. Public displays of affection are generally discouraged."
    },
    dance: [
      { name: "Lion Dance", description: "Performed during festivals like Tet.", imageUrl: "lion-dance" },
      { name: "Water Puppetry", description: "A unique Vietnamese art form where puppets are controlled over water.", imageUrl: "water-puppets" }
    ],
    culture: {
      traditions: ["Ancestral Worship", "Tet (Lunar New Year)", "Family-centric values"],
      festivals: ["Tet", "Mid-Autumn Festival", "Hue Festival"],
      laws: ["Strict laws on political expression", "Strict drug laws"]
    },
    ethnicity: ["Kinh (Viet) (85%)", "Tay", "Thai", "Muong", "Over 50 ethnic groups"],
    generalInfo: "A country with a long history of resilience and a rapidly growing economy, deeply influenced by its Confucian heritage."
  },
  "Philippines": {
    food: [
      { name: "Adobo", description: "Meat (usually chicken or pork) marinated in vinegar, soy sauce, garlic, and peppercorns, then simmered until tender.", etiquette: "Best eaten with rice; often better the next day.", imageUrl: "adobo" },
      { name: "Lechon", description: "Whole roasted pig, a centerpiece of Filipino celebrations.", etiquette: "The skin is highly prized for its crispiness.", imageUrl: "lechon" },
      { name: "Sinigang", description: "A sour soup or stew characterized by its sour and savory taste, often associated with tamarind.", etiquette: "Often served as a comfort food during rainy days.", imageUrl: "sinigang" }
    ],
    clothing: [
      { name: "Barong Tagalog", description: "An embroidered formal shirt and considered the national dress of the Philippines.", situations: "Worn by men for weddings, formal events, and government functions.", imageUrl: "barong" },
      { name: "Baro't Saya", description: "Traditional dress worn by women, consisting of a blouse and a skirt.", situations: "Worn for formal occasions and cultural festivals.", imageUrl: "barot-saya" }
    ],
    language: {
      phrases: [
        { phrase: "Salamat", meaning: "Thank You" },
        { phrase: "Kumusta?", meaning: "How are you?" },
        { phrase: "Mabuhay", meaning: "Welcome/Long Live" }
      ],
      etiquette: "Filipinos are known for their hospitality. 'Mano Po' is a gesture of respect for elders where one takes the elder's hand and presses it to their forehead.",
      dialects: ["Cebuano", "Ilocano", "Hiligaynon", "Waray-Waray", "Chavacano"]
    },
    etiquette: {
      dos: [
        "Use 'po' and 'opo' when speaking to elders.",
        "Practice 'Mano Po' with elders.",
        "Be hospitable and friendly.",
        "Remove shoes when asked."
      ],
      donts: [
        "Don't refuse an offer of food – it's considered rude.",
        "Avoid criticizing someone's family.",
        "Don't speak in a loud tone – it's considered aggressive.",
        "Don't point with your finger; use your eyes or lips instead."
      ],
      greetings: "A handshake is common. 'Mano' is the traditional way to greet elders. Filipinos often use a 'pout' of the lips to point to something.",
      giftGiving: "Gifts are not usually opened in front of the giver. Avoid giving 13 of anything (considered unlucky).",
      socialNorms: "The concept of 'Pakikisama' (getting along with others) and 'Utang na Loob' (debt of gratitude) are very important."
    },
    dance: [
      { name: "Tinikling", description: "A traditional dance involving two people beating, tapping, and sliding bamboo poles on the ground and against each other in coordination with dancers who step over and in between the poles.", imageUrl: "tinikling" },
      { name: "Singkil", description: "A royal fan dance from the Maranao people of Mindanao.", imageUrl: "singkil" }
    ],
    culture: {
      traditions: ["Bayanihan (Community Spirit)", "Pamanhikan (Marriage Proposal)", "Fiesta culture"],
      festivals: ["Sinulog", "Ati-Atihan", "Panagbenga", "Pahiyas"],
      laws: ["Strict anti-drug laws", "Local ordinances can be strict (e.g., smoking bans)"]
    },
    ethnicity: ["Tagalog", "Cebuano", "Ilocano", "Bicolano", "Moro groups", "Indigenous peoples (Igorot, Lumad)"],
    generalInfo: "An archipelago of 7,000+ islands with a unique blend of Spanish, American, and indigenous influences."
  },
  "Singapore": {
    food: [
      { name: "Hainan Chicken Rice", description: "Poached chicken and seasoned rice, served with chili sauce and cucumber garnishes.", etiquette: "A national favorite; found in almost every hawker center.", imageUrl: "chicken-rice" },
      { name: "Chili Crab", description: "Crab stir-fried in a semi-thick, sweet and savory tomato-and-chili-based sauce.", etiquette: "Usually eaten with fried mantou (buns) to soak up the sauce.", imageUrl: "chili-crab" },
      { name: "Laksa", description: "Spicy noodle soup with a coconut milk base.", etiquette: "The Katong version is famous for having noodles cut into smaller pieces, eaten only with a spoon.", imageUrl: "laksa" }
    ],
    clothing: [
      { name: "Modern Attire", description: "Western-style clothing is common in this global hub.", situations: "Standard for daily life and business.", imageUrl: "singapore-modern" },
      { name: "Ethnic Traditional Wear", description: "Traditional outfits like Cheongsam, Baju Kurung, and Saree worn during festivals.", situations: "Worn during religious festivals, weddings, and Racial Harmony Day.", imageUrl: "singapore-ethnic" }
    ],
    language: {
      phrases: [
        { phrase: "Thank You", meaning: "Thank You" },
        { phrase: "How are you?", meaning: "How are you?" }
      ],
      etiquette: "English, Malay, Mandarin, and Tamil are official languages. Efficiency and punctuality are highly valued.",
      dialects: ["Hokkien", "Teochew", "Cantonese", "Hakka", "Singlish (Colloquial English)"]
    },
    etiquette: {
      dos: ["Queue up", "Be punctual", "Clear your tray at hawker centers", "High social order"],
      donts: ["Don't litter", "Don't chew gum", "Don't smoke in prohibited areas", "Don't break public order laws", "Don't practice racial discrimination"],
      greetings: "A handshake is the norm. For older Chinese, a slight bow is respectful.",
      giftGiving: "Avoid giving clocks (associated with death) or umbrellas (associated with separation) to Chinese Singaporeans.",
      socialNorms: "Singaporeans value 'Kiasu' (competitiveness) but also maintain a high level of social courtesy and order."
    },
    dance: [
      { name: "Multicultural Performances", description: "Dances reflecting Chinese, Malay, and Indian heritage.", imageUrl: "sg-dance" }
    ],
    culture: {
      traditions: ["Hawker Culture", "Kiasuism (Fear of losing out)", "Urban multicultural lifestyle"],
      festivals: ["National Day", "Chinese New Year", "Hari Raya", "Deepavali"],
      laws: ["Strict laws against littering, vandalism, and drug trafficking", "Fines are common for minor offenses"]
    },
    ethnicity: ["Chinese (74%)", "Malay (13%)", "Indian (9%)", "Eurasian communities"],
    generalInfo: "A highly developed city-state known for its efficiency, cleanliness, and multicultural harmony."
  },
  "Myanmar": {
    food: [
      { name: "Mohinga", description: "Rice noodles in a fish-based soup, considered the national dish of Myanmar.", etiquette: "Commonly eaten for breakfast; often sold by street vendors.", imageUrl: "mohinga" },
      { name: "Lahpet Thoke", description: "Fermented tea leaf salad.", etiquette: "A unique Burmese snack, often served at the end of a meal or to guests.", imageUrl: "lahpet" },
      { name: "Traditional Curries", description: "Rich and savory curries served with rice.", etiquette: "Usually served with a variety of side dishes and fresh vegetables.", imageUrl: "burmese-curry" }
    ],
    clothing: [
      { name: "Longyi", description: "A sheet of cloth widely worn in Myanmar, wrapped around the waist by both men and women.", situations: "Worn for daily life, work, and formal occasions.", imageUrl: "longyi" },
      { name: "Acheik", description: "Intricately patterned silk fabric used for formal longyis.", situations: "Worn for weddings and royal ceremonies.", imageUrl: "acheik" }
    ],
    language: {
      phrases: [
        { phrase: "Mingalaba", meaning: "Hello" },
        { phrase: "Nay Kaung Lar?", meaning: "How are you?" }
      ],
      etiquette: "Burmese is the official language. Respect for monks and elders is very important.",
      dialects: ["Shan", "Karen", "Kachin", "Mon", "Rakhine"]
    },
    etiquette: {
      dos: ["Remove shoes in pagodas", "Dress modestly", "Respect monks", "Use both hands when giving/receiving"],
      donts: ["Don't touch heads", "Don't point with feet", "Don't use your left hand for giving", "Don't behave inappropriately near religious sites"],
      greetings: "A slight bow with hands at the side is common. 'Mingalaba' is the universal greeting.",
      giftGiving: "Gifts are given with both hands. Avoid giving anything made of dog or pig skin to Muslims.",
      socialNorms: "The concept of 'Anade' (reluctance to cause someone else inconvenience) is a key social value."
    },
    dance: [
      { name: "Traditional Puppet Theatre", description: "A classical Burmese entertainment form using string puppets.", imageUrl: "burmese-puppets" },
      { name: "Classical Dance", description: "Stylized traditional dance performances.", imageUrl: "burmese-dance" }
    ],
    culture: {
      traditions: ["Shinbyu (Novitiation Ceremony)", "Thanaka (Cosmetic Paste)", "Traditional community structure"],
      festivals: ["Thingyan (Water Festival)", "Thadingyut"],
      laws: ["Strict laws regarding religious sites and images", "Political sensitivity is high"]
    },
    ethnicity: ["Bamar (68%)", "Shan (9%)", "Karen (7%)", "Rakhine (4%)", "Mon", "Kachin"],
    generalInfo: "A country with a rich Buddhist heritage and a diverse tapestry of ethnic groups, currently navigating a complex political landscape."
  },
  "Cambodia": {
    food: [
      { name: "Amok", description: "Steamed fish curry in banana leaves, the national dish.", etiquette: "Often served in a coconut shell or banana leaf boat.", imageUrl: "amok" },
      { name: "Lok Lak", description: "Stir-fried beef with black pepper.", etiquette: "Served with a dipping sauce of lime juice, salt, and black pepper.", imageUrl: "lok-lak" },
      { name: "Num Banh Chok", description: "Rice noodles with green curry.", etiquette: "A popular breakfast dish often sold by women carrying it on poles.", imageUrl: "num-banh-chok" }
    ],
    clothing: [
      { name: "Sampot", description: "A long, rectangular cloth worn around the lower body.", situations: "Worn for daily life and formal ceremonies; different styles indicate social status.", imageUrl: "sampot" },
      { name: "Krama", description: "Traditional Cambodian checkered scarf.", situations: "Used for everything from a head covering to a baby carrier.", imageUrl: "krama" }
    ],
    language: {
      phrases: [
        { phrase: "Choum Reap Sour", meaning: "Hello (Formal)" },
        { phrase: "Orkun", meaning: "Thank You" }
      ],
      etiquette: "The 'Sampeah' is the traditional greeting. Avoid touching someone's head.",
      dialects: ["Phnom Penh", "Battambang", "Cardamom Khmer"]
    },
    etiquette: {
      dos: ["Sampeah when greeting", "Remove shoes in homes/temples", "Dress modestly"],
      donts: ["Don't touch heads", "Don't point with feet", "Don't show public affection"],
      greetings: "The 'Sampeah' (palms together at chest level) is the standard greeting. The higher the hands, the more respect.",
      giftGiving: "Gifts are usually given for weddings and housewarmings. Avoid giving white flowers (associated with funerals).",
      socialNorms: "Respect for elders and monks is deeply ingrained. 'Saving face' is important in social interactions."
    },
    dance: [
      { name: "Apsara Dance", description: "A classical Khmer dance inspired by the apsara carvings of Angkor Wat.", imageUrl: "apsara" },
      { name: "Robam Trot", description: "A popular folk dance performed during the Khmer New Year.", imageUrl: "robam-trot" }
    ],
    culture: {
      traditions: ["Bonn Om Touk (Water Festival)", "Khmer New Year", "Ancestral respect"],
      festivals: ["Khmer New Year", "Pchum Ben", "Water Festival"],
      laws: ["Strict laws regarding cultural heritage and antiquities", "Strict drug laws"]
    },
    ethnicity: ["Khmer (90%)", "Vietnamese", "Chinese", "Cham"],
    generalInfo: "Home to the magnificent Angkor Wat, Cambodia has a rich cultural heritage and a resilient spirit."
  },
  "Laos": {
    food: [
      { name: "Sticky Rice", description: "The staple food of Laos, eaten with hands.", etiquette: "Roll the rice into small balls and dip into sauces or meat.", imageUrl: "sticky-rice" },
      { name: "Laap (Larb)", description: "A minced meat salad flavored with lime, fish sauce, and herbs.", etiquette: "Often served with fresh vegetables and sticky rice.", imageUrl: "larb" },
      { name: "Grilled Meat", description: "Traditional grilled meats and fish dishes.", etiquette: "Commonly found at night markets.", imageUrl: "lao-grill" }
    ],
    clothing: [
      { name: "Sinh", description: "A traditional tube skirt worn by Lao women.", situations: "Worn for daily life, work, and formal ceremonies.", imageUrl: "sinh" },
      { name: "Salong", description: "Traditional baggy trousers worn by Lao men for formal occasions.", situations: "Worn at weddings and state functions.", imageUrl: "salong" }
    ],
    language: {
      phrases: [
        { phrase: "Sabaidee", meaning: "Hello" },
        { phrase: "Khop Chai", meaning: "Thank You" }
      ],
      etiquette: "Lao is the official language. Respect for Buddhism and the simple rural lifestyle is central.",
      dialects: ["Vientiane", "Luang Prabang", "Pakse"]
    },
    etiquette: {
      dos: ["Dress modestly", "Remove shoes in temples", "Be polite", "Respect elders and monks"],
      donts: ["Don't touch heads", "Don't point with feet", "Don't step over people", "Don't display public anger"],
      greetings: "The 'Nop' (palms together at chest level) is the traditional greeting. A slight bow is also common.",
      giftGiving: "Gifts are usually given for housewarmings and weddings. Avoid giving anything made of white cloth (associated with death).",
      socialNorms: "Lao people are known for being relaxed and 'Jai Yen' (cool-hearted)."
    },
    dance: [
      { name: "Lam Vong", description: "A traditional Lao folk dance.", imageUrl: "lam-vong" }
    ],
    culture: {
      traditions: ["Alms Giving (Sai Bat)", "Baci Ceremony", "Simple rural lifestyle"],
      festivals: ["Pi Mai (Lao New Year)", "That Luang Festival"],
      laws: ["Strict laws regarding religious sites", "Strict drug laws"]
    },
    ethnicity: ["Lao (55%)", "Khmu", "Hmong", "Over 40 ethnic groups"],
    generalInfo: "A landlocked country with a peaceful atmosphere and a strong commitment to preserving its traditional way of life."
  },
  "Brunei": {
    food: [
      { name: "Ambuyat", description: "A dish derived from the interior trunk of the sago palm, eaten with a bamboo fork called candas.", etiquette: "The sago is twirled around the candas and dipped into a variety of savory sauces.", imageUrl: "ambuyat" },
      { name: "Nasi Katok", description: "Rice served with fried chicken and sambal.", etiquette: "A popular and affordable staple found throughout Brunei.", imageUrl: "nasi-katok" }
    ],
    clothing: [
      { name: "Baju Kurung", description: "Commonly worn by women.", situations: "Standard wear for work, school, and formal events.", imageUrl: "brunei-kurung" },
      { name: "Cara Melayu", description: "Traditional Malay dress for men.", situations: "Worn for formal occasions and religious ceremonies.", imageUrl: "cara-melayu" }
    ],
    language: {
      phrases: [
        { phrase: "Selamat Pagi", meaning: "Good Morning" },
        { phrase: "Terima Kasih", meaning: "Thank You" }
      ],
      etiquette: "Brunei is a Malay Islamic Monarchy. Respect for Islam and the Sultan is essential.",
      dialects: ["Brunei Malay", "Tutong", "Belait", "Dusun"]
    },
    etiquette: {
      dos: ["Dress modestly", "Respect Islamic customs", "Use right hand"],
      donts: ["Don't point with index finger", "Don't show public affection", "Don't consume alcohol in public"],
      greetings: "A handshake is common, but men should wait for a woman to offer her hand first. A slight bow is also respectful.",
      giftGiving: "Avoid giving alcohol or anything made of pig skin. Use your right hand to give and receive.",
      socialNorms: "Bruneians are generally conservative and value social harmony and respect for authority."
    },
    dance: [
      { name: "Adai-Adai", description: "A traditional dance of the fishing community.", imageUrl: "adai-adai" }
    ],
    culture: {
      traditions: ["Islamic values", "Royal traditions", "Malay heritage"],
      festivals: ["Hari Raya Aidilfitri", "Sultan's Birthday", "National Day"],
      laws: ["Sharia law is implemented", "Strict drug laws", "Alcohol is prohibited"]
    },
    ethnicity: ["Malay (66%)", "Chinese (10%)", "Indigenous groups"],
    generalInfo: "A small, oil-rich sultanate with a strong Islamic identity and a high standard of living."
  },
  "Timor Leste": {
    food: [
      { name: "Corn-based Dishes", description: "Staple corn dishes often served with beans.", etiquette: "Corn is a primary staple, especially in rural areas.", imageUrl: "timor-corn" },
      { name: "Ikan Sabuko", description: "Tamarind-marinated fish grilled in banana leaves.", etiquette: "A popular coastal dish.", imageUrl: "ikan-sabuko" },
      { name: "Batar Da'an", description: "A popular dish of corn, mung beans, and pumpkin.", etiquette: "A hearty and nutritious stew.", imageUrl: "batar-daan" }
    ],
    clothing: [
      { name: "Tais", description: "Traditional hand-woven textile, used for clothing and ceremonies.", situations: "Worn for weddings, funerals, and cultural festivals; also used as a sign of respect for guests.", imageUrl: "tais" },
      { name: "Tribal Ceremonial Attire", description: "Traditional wear for tribal ceremonies.", situations: "Worn during sacred rituals and community celebrations.", imageUrl: "timor-tribal-wear" }
    ],
    language: {
      phrases: [
        { phrase: "Bondia", meaning: "Good Morning" },
        { phrase: "Obrigadu", meaning: "Thank You" },
        { phrase: "Di'ak ka lae?", meaning: "How are you?" }
      ],
      etiquette: "Tetum and Portuguese are official languages. Indonesian and local languages are also used.",
      dialects: ["Mambae", "Makasae", "Baikenu", "Bunak"]
    },
    etiquette: {
      dos: ["Dress modestly", "Greet people with a handshake", "Respect religious sites", "Respect ancestral traditions"],
      donts: ["Don't use your left hand for giving/receiving", "Don't touch heads", "Don't point with your finger", "Don't disrespect sacred land"],
      greetings: "A handshake is standard. In rural areas, people may also touch their heart after shaking hands.",
      giftGiving: "Gifts are usually given for community events. Avoid giving anything that could be seen as disrespectful to local customs.",
      socialNorms: "Community and family ties are very strong. Respect for 'Lulik' (the sacred) is fundamental to Timorese life."
    },
    dance: [
      { name: "Tebedai", description: "A traditional dance performed to welcome guests or celebrate harvest.", imageUrl: "tebedai" },
      { name: "Ritual Dances", description: "Traditional dances performed during cultural ceremonies.", imageUrl: "timor-ritual-dance" }
    ],
    culture: {
      traditions: ["Tais weaving", "Respect for 'Lulik' (sacred places)", "Strong community ties", "Tribal customs"],
      festivals: ["Independence Day", "Proclamation of Independence", "Catholic festivals"],
      laws: ["Customary laws (Tara Bandu) are often used for community management", "Strict drug laws"]
    },
    ethnicity: ["Austronesian ethnic groups", "Portuguese cultural influence"],
    generalInfo: "The youngest ASEAN member, Timor Leste has a rich history and a unique blend of Southeast Asian and Portuguese influences."
  }
};
