/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Utensils, 
  Shirt, 
  Languages, 
  ShieldAlert, 
  Music, 
  History, 
  Camera,
  ArrowLeft,
  Info,
  Compass,
  Landmark,
  Users,
  MapPin,
  ArrowDown,
  Sparkles,
  Globe
} from 'lucide-react';
import { ASEAN_COUNTRIES, CountryTheme } from './constants';
import { CultureScanner } from './components/CultureScanner';
import { AICulturalAssistant } from './components/AICulturalAssistant';
import { CULTURAL_DATA } from './data/culturalData';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { CulturalInfo } from './services/gemini';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [selectedCountry, setSelectedCountry] = useState<CountryTheme | null>(null);
  const [culturalData, setCulturalData] = useState<CulturalInfo | null>(null);
  const [activeTab, setActiveTab] = useState<'food' | 'clothing' | 'people' | 'language' | 'customs' | 'dance' | 'taboos' | 'general'>('food');
  const [showScanner, setShowScanner] = useState(false);
  const [showAssistant, setShowAssistant] = useState(false);

  const countryGridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedCountry) {
      setCulturalData(CULTURAL_DATA[selectedCountry.name] || null);
    } else {
      setCulturalData(null);
    }
  }, [selectedCountry]);

  const scrollToGrid = () => {
    countryGridRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const categories = [
    { id: 'food', label: 'Food', icon: Utensils },
    { id: 'clothing', label: 'Clothing', icon: Shirt },
    { id: 'people', label: 'People & Ethnicity', icon: Users },
    { id: 'language', label: 'Language', icon: Languages },
    { id: 'customs', label: 'Culture & Customs', icon: Landmark },
    { id: 'dance', label: 'Dance & Arts', icon: Music },
    { id: 'taboos', label: 'Taboos', icon: ShieldAlert },
    { id: 'general', label: 'General Info', icon: Info },
  ] as const;

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-[#1E293B] overflow-x-hidden">
      <AnimatePresence mode="wait">
        {!selectedCountry ? (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative min-h-screen flex flex-col bg-[#003399]"
          >
            {/* Main Background - Fixed */}
            <div className="fixed inset-0 z-0 bg-[#001A4D]">
              {/* ASEAN Color Glow */}
              <div className="absolute inset-0 bg-gradient-to-b from-[#003399] via-[#ED1C24]/40 to-[#F8FAFC]" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#ED1C24]/40 via-transparent to-transparent" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#FECA06]/20 via-transparent to-transparent scale-150" />
            </div>

            {/* Decorative Top Border - Intricate Pattern */}
            <div className="sticky top-0 left-0 right-0 h-32 bg-[#001A4D] border-b-4 border-[#ED1C24] z-50 overflow-hidden shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
               <div className="absolute inset-0 opacity-60 heritage-pattern scale-[2.0]" />
               <div className="relative h-full flex items-center justify-center">
                  <div className="flex gap-16 opacity-40 whitespace-nowrap">
                    {Array(15).fill(0).map((_, i) => (
                      <span key={i} className="text-[#FECA06] font-serif text-3xl font-bold tracking-[0.2em]">◈ ASEAN CULTURAL GUIDE ◈</span>
                    ))}
                  </div>
               </div>
            </div>

            {/* Hero Section */}
            <div className="relative min-h-screen flex items-center justify-center overflow-hidden z-10 pt-20 pb-32">
              <div className="relative z-10 text-center px-4 max-w-5xl">
                <motion.div
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1, duration: 0.4 }}
                >
                  <div className="inline-flex items-center gap-2 px-6 py-2 rounded-full border border-[#FECA06]/50 bg-[#003399]/80 text-[#FECA06] font-medium text-sm mb-6 backdrop-blur-md">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    >
                      <Compass size={16} />
                    </motion.div>
                    Heritage Explorer
                  </div>
                  <h1 className="text-5xl md:text-7xl font-serif text-white mb-4 tracking-tight leading-tight drop-shadow-2xl">
                    Learn the Culture of <br/>
                    <span className="text-[#FECA06] italic">ASEAN With SeaAI</span>
                  </h1>
                  <p className="text-white/90 text-2xl md:text-3xl font-cultural italic max-w-4xl mx-auto mb-12 leading-relaxed drop-shadow-lg">
                    Learn about food, clothing, language, customs, and taboos of each ASEAN country.
                  </p>
                  
                  <button 
                    onClick={scrollToGrid}
                    className="group bg-[#ED1C24] text-white px-12 py-6 rounded-full font-bold text-2xl shadow-2xl hover:bg-[#C1121C] transition-all flex items-center gap-3 mx-auto border-2 border-white/20"
                  >
                    Start Exploring
                    <ArrowDown size={28} className="group-hover:translate-y-1 transition-transform" />
                  </button>
                </motion.div>
              </div>
            </div>

            {/* Country Grid Section */}
            <div ref={countryGridRef} className="relative z-10 max-w-7xl mx-auto px-6 py-24 w-full">
              <div className="absolute inset-0 bg-[#001A4D]/40 backdrop-blur-[2px] rounded-[3rem] -z-10" />
              <div className="text-center mb-16 relative">
                <h2 className="text-4xl md:text-6xl font-serif text-white mb-4 drop-shadow-[0_5px_15px_rgba(0,0,0,0.5)]">Choose an ASEAN Country</h2>
                <p className="text-white/90 text-lg md:text-xl font-medium drop-shadow-md">Explore the culture of 10 Southeast Asian countries and learn about it</p>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-8">
                {ASEAN_COUNTRIES.map((country, idx) => (
                  <motion.button
                    key={country.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    whileHover={{ 
                      scale: 1.05,
                      transition: { type: "spring", stiffness: 800, damping: 25 }
                    }}
                    whileTap={{ scale: 0.98 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.02 * (idx % 3), type: "spring", stiffness: 300 }}
                    onClick={() => setSelectedCountry(country)}
                    className={cn(
                      "group relative h-28 sm:h-64 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border-2 border-transparent hover:border-white/60",
                      country.primaryColor
                    )}
                  >
                    <div className="absolute inset-0 p-2 sm:p-8 flex flex-col items-center justify-center text-center">
                      <span className="text-3xl sm:text-7xl font-serif text-[#1E293B] mb-1 sm:mb-4 tracking-tighter opacity-80 group-hover:opacity-100 transition-opacity drop-shadow-sm">
                        {country.code}
                      </span>
                      <h3 className={cn("text-xs sm:text-2xl font-serif font-bold mb-0.5 sm:mb-2 flex items-center justify-center gap-1 sm:gap-3", country.secondaryColor)}>
                        <div className="relative w-5 h-5 sm:w-10 sm:h-10 rounded-full overflow-hidden border border-white shadow-sm sm:shadow-lg flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                          <img 
                            src={`https://flagcdn.com/w160/${country.code.toLowerCase()}.png`}
                            alt={`${country.name} flag`}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-white/40 pointer-events-none" />
                        </div>
                        {country.name}
                      </h3>
                      <div className="flex items-center gap-2 text-[#64748B] text-sm group-hover:text-[#1E293B] transition-colors">
                        <MapPin size={14} />
                        {country.capital}
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Decorative Bottom Border */}
            <div className="relative h-40 bg-[#001A4D] border-t-4 border-[#ED1C24] z-10 overflow-hidden mt-auto shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
               <div className="absolute inset-0 opacity-60 heritage-pattern scale-[2.0]" />
               <div className="relative h-full flex items-center justify-center">
                  <div className="flex gap-16 opacity-40 whitespace-nowrap">
                    {Array(15).fill(0).map((_, i) => (
                      <span key={i} className="text-[#FECA06] font-serif text-3xl font-bold tracking-[0.2em]">◈ RESPECT TRADITIONS ◈</span>
                    ))}
                  </div>
               </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="country-detail"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="min-h-screen flex flex-col bg-white"
          >
            {/* New Header Style */}
            <div className={cn("relative pt-8 pb-12 px-6 md:px-12", selectedCountry.primaryColor)}>
              <div className="max-w-7xl mx-auto">
                <button 
                  onClick={() => setSelectedCountry(null)}
                  className="flex items-center gap-2 text-[#1E293B]/60 hover:text-[#1E293B] transition-colors font-medium mb-8"
                >
                  <ArrowLeft size={20} />
                  Back
                </button>

                <div className="flex items-baseline gap-6">
                  <span className="text-6xl md:text-7xl font-bold text-[#1E293B] opacity-100 tracking-tighter leading-none">
                    {selectedCountry.code}
                  </span>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-4 mb-2">
                      <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-xl flex-shrink-0">
                        <img 
                          src={`https://flagcdn.com/w160/${selectedCountry.code.toLowerCase()}.png`}
                          alt={`${selectedCountry.name} flag`}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-white/40 pointer-events-none" />
                      </div>
                      <h2 className={cn("text-4xl md:text-6xl font-serif font-bold leading-none", selectedCountry.secondaryColor)}>
                        {selectedCountry.name}
                      </h2>
                    </div>
                    <p className="text-lg md:text-xl text-[#1E293B] font-medium opacity-80">
                      {selectedCountry.name} · {selectedCountry.greeting}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tab Navigation - Pill Style */}
            <div className="max-w-7xl mx-auto w-full px-4 md:px-12 py-6 md:py-12 relative z-10">
              <div className="flex flex-wrap gap-2 md:gap-3 mb-8 md:mb-12">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveTab(cat.id)}
                    style={{ 
                      backgroundColor: activeTab === cat.id ? selectedCountry.hexColor : 'white',
                      borderColor: activeTab === cat.id ? selectedCountry.hexColor : '#E2E8F0',
                      color: activeTab === cat.id ? 'white' : selectedCountry.hexColor
                    }}
                    className={cn(
                      "flex items-center gap-2 px-4 md:px-6 py-2 md:py-3 rounded-full font-medium transition-all text-xs md:text-sm border-2 shadow-sm",
                      activeTab !== cat.id && "hover:bg-[#F8FAFC]"
                    )}
                  >
                    <cat.icon size={16} className="md:w-[18px] md:h-[18px]" />
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Content Section */}
              <div className="max-w-4xl pb-16 md:pb-24">
                <h3 className={cn("text-2xl md:text-4xl font-serif mb-2 capitalize", selectedCountry.secondaryColor)}>{activeTab}</h3>
                <p className="text-[#64748B] text-base md:text-lg mb-8 md:text-xl">
                  {activeTab === 'food' && 'Traditional dishes & dining etiquette'}
                  {activeTab === 'clothing' && 'Traditional attire & dress codes'}
                  {activeTab === 'people' && 'Ethnic groups & social structure'}
                  {activeTab === 'language' && 'Common phrases & linguistic nuances'}
                  {activeTab === 'customs' && 'Social norms & traditional customs'}
                  {activeTab === 'dance' && 'Traditional performances & artistic heritage'}
                  {activeTab === 'taboos' && 'Things that are forbidden & should be avoided'}
                  {activeTab === 'general' && 'Essential travel information'}
                </p>

                {culturalData ? (
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    {/* Render content based on activeTab */}
                    {activeTab === 'food' && culturalData.food.map((item, i) => (
                      <div 
                        key={i} 
                        style={{ borderLeftColor: selectedCountry.hexColor }}
                        className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
                      >
                        <div className="flex flex-col gap-2 flex-1">
                          <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">
                            <span className="font-bold">{item.name}</span> – {item.description}
                          </p>
                          {item.etiquette && (
                            <p className="text-sm md:text-base text-[#64748B] italic flex items-center gap-2">
                              <Info size={16} className="text-blue-500" />
                              Etiquette: {item.etiquette}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                    
                    {activeTab === 'clothing' && culturalData.clothing.map((item, i) => (
                      <div 
                        key={i} 
                        style={{ borderLeftColor: selectedCountry.hexColor }}
                        className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
                      >
                        <div className="flex flex-col gap-2 flex-1">
                          <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">
                            <span className="font-bold">{item.name}</span> – {item.description}
                          </p>
                          {item.situations && (
                            <p className="text-sm md:text-base text-[#64748B] italic flex items-center gap-2">
                              <MapPin size={16} className="text-emerald-500" />
                              When to wear: {item.situations}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}

                    {activeTab === 'people' && (
                      <div className="space-y-8 md:space-y-12">
                        {culturalData.ethnicity && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                            {culturalData.ethnicity.map((e, i) => (
                              <div 
                                key={i} 
                                style={{ borderLeftColor: selectedCountry.hexColor }}
                                className="group p-4 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm hover:shadow-md transition-all flex items-center gap-4"
                              >
                                <span className="text-base md:text-xl font-bold text-[#1E293B]">{e}</span>
                              </div>
                            ))}
                          </div>
                        )}

                        <div 
                          style={{ borderLeftColor: selectedCountry.hexColor }}
                          className="p-6 md:p-10 bg-white rounded-3xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                        >
                          <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-6">Cultural Traditions</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {culturalData.culture.traditions.map((t, i) => (
                              <div key={i} className="flex flex-col gap-3">
                                <p className="text-base md:text-lg text-[#1E293B] font-medium flex items-start gap-2">
                                  <span style={{ color: selectedCountry.hexColor }} className="mt-1">◈</span>
                                  {t}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {activeTab === 'language' && (
                      <div className="space-y-4 md:space-y-6">
                        <div 
                          style={{ borderLeftColor: selectedCountry.hexColor }}
                          className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                        >
                          <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Common Phrases</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                            {culturalData.language.phrases.map((p, i) => (
                              <div key={i} className="p-3 md:p-4 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0]">
                                <p className="font-bold text-[#1E293B] text-sm md:text-base">{p.phrase}</p>
                                <p className="text-[#64748B] text-xs md:text-sm">{p.meaning}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                        {culturalData.language.dialects && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Regional Dialects</h4>
                            <div className="flex flex-wrap gap-2">
                              {culturalData.language.dialects.map((d, i) => (
                                <span key={i} className="px-3 md:px-4 py-1.5 md:py-2 bg-[#F1F5F9] text-[#1E293B] rounded-full text-xs md:text-sm font-medium border border-[#E2E8F0]">
                                  {d}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        <div 
                          style={{ borderLeftColor: selectedCountry.hexColor }}
                          className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                        >
                          <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Linguistic Etiquette</h4>
                          <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">{culturalData.language.etiquette}</p>
                        </div>
                      </div>
                    )}

                    {activeTab === 'customs' && (
                      <div className="space-y-4 md:space-y-6">
                        <div 
                          style={{ borderLeftColor: selectedCountry.hexColor }}
                          className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                        >
                          <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Social Dos</h4>
                          <ul className="space-y-3 md:space-y-4">
                            {culturalData.etiquette.dos.map((item, i) => (
                              <li key={i} className="text-base md:text-xl text-[#1E293B] flex items-start gap-2 md:gap-3">
                                <span className="text-emerald-500 mt-1 text-xs md:text-base">✓</span>
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>
                        {culturalData.etiquette.greetings && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Greetings</h4>
                            <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">{culturalData.etiquette.greetings}</p>
                          </div>
                        )}
                        {culturalData.etiquette.giftGiving && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Gift Giving</h4>
                            <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">{culturalData.etiquette.giftGiving}</p>
                          </div>
                        )}
                        {culturalData.etiquette.socialNorms && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Social Norms</h4>
                            <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">{culturalData.etiquette.socialNorms}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === 'dance' && culturalData.dance.map((item, i) => (
                      <div 
                        key={i} 
                        style={{ borderLeftColor: selectedCountry.hexColor }}
                        className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
                      >
                        <div className="flex-1">
                          <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">
                            <span className="font-bold">{item.name}</span> – {item.description}
                          </p>
                        </div>
                      </div>
                    ))}
                    
                    {activeTab === 'taboos' && (
                      <div className="space-y-6 md:space-y-10">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                          {culturalData.etiquette.donts.map((item, i) => (
                            <div 
                              key={i} 
                              className="group p-4 md:p-6 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 border-l-red-500 shadow-sm hover:shadow-md transition-all flex flex-col gap-4"
                            >
                              <p className="text-base md:text-lg text-[#1E293B] leading-relaxed flex items-start gap-2">
                                <span className="text-red-500 mt-1">✕</span>
                                {item}
                              </p>
                            </div>
                          ))}
                        </div>
                        {culturalData.culture.laws && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Local Laws to Note</h4>
                            <ul className="space-y-3 md:space-y-4">
                              {culturalData.culture.laws.map((law, i) => (
                                <li key={i} className="text-base md:text-xl text-[#1E293B] flex items-start gap-2 md:gap-3">
                                  <ShieldAlert size={20} className="text-red-500 mt-1 shrink-0" />
                                  {law}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === 'general' && (
                      <div className="space-y-4 md:space-y-6">
                        {culturalData.generalInfo && (
                          <div 
                            style={{ borderLeftColor: selectedCountry.hexColor }}
                            className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                          >
                            <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Overview</h4>
                            <p className="text-base md:text-xl text-[#1E293B] leading-relaxed">{culturalData.generalInfo}</p>
                          </div>
                        )}
                        <div 
                          style={{ borderLeftColor: selectedCountry.hexColor }}
                          className="p-4 md:p-8 bg-white rounded-2xl border-2 border-[#E2E8F0] border-l-8 shadow-sm"
                        >
                          <h4 className="text-xs md:text-sm uppercase tracking-widest text-[#64748B] mb-3 md:mb-4">Major Festivals</h4>
                          <div className="flex flex-wrap gap-2">
                            {culturalData.culture.festivals.map((f, i) => (
                              <span key={i} className="px-3 md:px-4 py-1.5 md:py-2 bg-[#F1F5F9] text-[#1E293B] rounded-full text-xs md:text-sm font-medium border border-[#E2E8F0]">
                                {f}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  <div className="p-12 bg-[#F8FAFC] rounded-3xl border-2 border-dashed border-[#CBD5E1] text-center">
                    <p className="text-[#64748B] italic">Discovering more about {selectedCountry.name}'s {activeTab}...</p>
                  </div>
                )}

                {/* New Scan & Identify Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-16">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    style={{ 
                      borderColor: selectedCountry.hexColor,
                      backgroundColor: `${selectedCountry.hexColor}05`
                    }}
                    className="p-8 md:p-12 rounded-3xl border-2 border-dashed flex flex-col items-center text-center"
                  >
                    <div 
                      style={{ backgroundColor: `${selectedCountry.hexColor}15`, color: selectedCountry.hexColor }}
                      className="p-4 rounded-2xl mb-6"
                    >
                      <Camera size={40} />
                    </div>
                    <h4 className="text-2xl md:text-3xl font-serif font-bold text-[#1E293B] mb-4">Culture Scanner</h4>
                    <p className="text-[#64748B] text-base md:text-lg max-w-md mb-8">
                      Identify traditional food, clothing, and landmarks using AI.
                    </p>
                    <button 
                      onClick={() => setShowScanner(true)}
                      style={{ 
                        borderColor: selectedCountry.hexColor,
                        color: selectedCountry.hexColor
                      }}
                      className="px-8 py-4 rounded-2xl border-2 font-bold hover:bg-white transition-all flex items-center gap-2"
                    >
                      <Camera size={20} />
                      Try Scanner
                    </button>
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    style={{ 
                      borderColor: selectedCountry.hexColor,
                      backgroundColor: `${selectedCountry.hexColor}05`
                    }}
                    className="p-8 md:p-12 rounded-3xl border-2 border-dashed flex flex-col items-center text-center"
                  >
                    <div 
                      style={{ backgroundColor: `${selectedCountry.hexColor}15`, color: selectedCountry.hexColor }}
                      className="p-4 rounded-2xl mb-6"
                    >
                      <Sparkles size={40} />
                    </div>
                    <h4 className="text-2xl md:text-3xl font-serif font-bold text-[#1E293B] mb-4">AI Assistant</h4>
                    <p className="text-[#64748B] text-base md:text-lg max-w-md mb-8">
                      Plan sustainable routes, learn dialects, or get agricultural advice.
                    </p>
                    <button 
                      onClick={() => setShowAssistant(true)}
                      style={{ 
                        backgroundColor: selectedCountry.hexColor,
                        color: 'white'
                      }}
                      className="px-8 py-4 rounded-2xl font-bold hover:opacity-90 transition-all flex items-center gap-2"
                    >
                      <Sparkles size={20} />
                      Open Assistant
                    </button>
                  </motion.div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showScanner && selectedCountry && (
          <CultureScanner 
            country={selectedCountry.name} 
            onClose={() => setShowScanner(false)} 
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAssistant && selectedCountry && (
          <AICulturalAssistant 
            countryName={selectedCountry.name} 
            onClose={() => setShowAssistant(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
