import React, { useRef, useState } from 'react';
import { Camera, X, Upload, Loader2, Sparkles, Languages } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { scanCultureImage, translateSignLanguage } from '../services/gemini';
import Markdown from 'react-markdown';
import { cn } from '../services/utils';

interface CultureScannerProps {
  country: string;
  onClose: () => void;
}

export const CultureScanner: React.FC<CultureScannerProps> = ({ country, onClose }) => {
  const [image, setImage] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [scanMode, setScanMode] = useState<'culture' | 'sign'>('culture');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showCamera, setShowCamera] = useState(false);

  const startCamera = async () => {
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setShowCamera(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setShowCamera(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!image) return;
    setScanning(true);
    try {
      const analysis = scanMode === 'culture' 
        ? await scanCultureImage(image, country)
        : await translateSignLanguage(image, country);
      setResult(analysis || "Could not process the image.");
    } catch (err) {
      console.error("Scan error:", err);
      setResult("Error analyzing image. Please try again.");
    } finally {
      setScanning(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <div className="bg-white rounded-2xl sm:rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        <div className="p-4 sm:p-6 border-b flex justify-between items-center bg-zinc-50">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-zinc-900 flex items-center gap-2">
              {scanMode === 'culture' ? <Sparkles className="text-[#F27D26]" size={20} /> : <Languages className="text-indigo-600" size={20} />}
              {scanMode === 'culture' ? 'Culture Scanner' : 'Sign Language Translator'}
            </h2>
            <p className="text-zinc-500 text-xs sm:text-sm">
              {scanMode === 'culture' ? `Scan items to learn about ${country}'s culture` : `Translate ${country} sign language in real-time`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-zinc-200 p-1 rounded-lg mr-2">
              <button 
                onClick={() => setScanMode('culture')}
                className={cn("px-3 py-1 text-xs font-bold rounded-md transition-all", scanMode === 'culture' ? "bg-white text-zinc-900 shadow-sm" : "text-zinc-500")}
              >
                Culture
              </button>
              <button 
                onClick={() => setScanMode('sign')}
                className={cn("px-3 py-1 text-xs font-bold rounded-md transition-all", scanMode === 'sign' ? "bg-white text-zinc-900 shadow-sm" : "text-zinc-500")}
              >
                Sign
              </button>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
              <X size={20} className="sm:w-6 sm:h-6" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {!image && !showCamera && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <button
                onClick={startCamera}
                className="flex flex-col items-center justify-center gap-3 sm:gap-4 p-8 sm:p-12 border-2 border-dashed border-zinc-200 rounded-2xl sm:rounded-3xl hover:border-[#F27D26] hover:bg-[#F27D26]/5 transition-all group"
              >
                <div className="p-3 sm:p-4 bg-[#F27D26]/10 rounded-xl sm:rounded-2xl group-hover:bg-[#F27D26]/20 transition-colors">
                  <Camera className="text-[#F27D26] w-6 h-6 sm:w-8 sm:h-8" />
                </div>
                <span className="font-semibold text-zinc-700 text-sm sm:text-base">Take a Photo</span>
              </button>
              <label className="flex flex-col items-center justify-center gap-3 sm:gap-4 p-8 sm:p-12 border-2 border-dashed border-zinc-200 rounded-2xl sm:rounded-3xl hover:border-emerald-500 hover:bg-emerald-50 transition-all group cursor-pointer">
                <div className="p-3 sm:p-4 bg-emerald-100 rounded-xl sm:rounded-2xl group-hover:bg-emerald-200 transition-colors">
                  <Upload className="text-emerald-600 w-6 h-6 sm:w-8 sm:h-8" />
                </div>
                <span className="font-semibold text-zinc-700 text-sm sm:text-base">Upload Image</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
              </label>
            </div>
          )}

          {showCamera && (
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-video">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
              <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
                <button
                  onClick={capturePhoto}
                  className="bg-white text-black px-6 py-3 rounded-full font-bold shadow-lg flex items-center gap-2 hover:scale-105 transition-transform"
                >
                  <Camera size={20} /> Capture
                </button>
                <button
                  onClick={stopCamera}
                  className="bg-zinc-800/80 text-white px-6 py-3 rounded-full font-bold backdrop-blur-md hover:bg-zinc-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {image && !scanning && !result && (
            <div className="space-y-6">
              <div className="relative rounded-2xl overflow-hidden shadow-lg aspect-video bg-zinc-100">
                <img src={image} className="w-full h-full object-contain" alt="Captured" />
                <button
                  onClick={() => setImage(null)}
                  className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <button
                onClick={handleScan}
                className={cn(
                  "w-full text-white py-4 rounded-2xl font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2",
                  scanMode === 'culture' ? "bg-[#F27D26] shadow-[#F27D26]/20 hover:bg-[#D97706]" : "bg-indigo-600 shadow-indigo-200 hover:bg-indigo-700"
                )}
              >
                {scanMode === 'culture' ? <Sparkles size={20} /> : <Languages size={20} />}
                {scanMode === 'culture' ? 'Analyze Culture' : 'Translate Sign'}
              </button>
            </div>
          )}

          {scanning && (
            <div className="flex flex-col items-center justify-center py-12 gap-4">
              <Loader2 className="animate-spin text-indigo-600" size={48} />
              <p className="text-zinc-600 font-medium animate-pulse">Consulting cultural experts...</p>
            </div>
          )}

          {result && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              <div className="rounded-2xl overflow-hidden shadow-md aspect-video max-h-48 bg-zinc-100">
                <img src={image!} className="w-full h-full object-contain" alt="Analyzed" />
              </div>
              <div className="prose prose-zinc max-w-none bg-zinc-50 p-6 rounded-2xl border border-zinc-100">
                <Markdown>{result}</Markdown>
              </div>
              <button
                onClick={() => { setResult(null); setImage(null); }}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold hover:bg-zinc-800 transition-all"
              >
                Scan Another
              </button>
            </motion.div>
          )}
        </div>
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </motion.div>
  );
};
